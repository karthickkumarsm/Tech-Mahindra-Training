import { FilterByYearPipe } from './filter-by-year.pipe';

describe('FilterByYearPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterByYearPipe();
    expect(pipe).toBeTruthy();
  });
});
