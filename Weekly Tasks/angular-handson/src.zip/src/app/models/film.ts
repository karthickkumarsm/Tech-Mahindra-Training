export interface Film {
  id: number;
  title: string;
  director: string;
  year: number;
  imageUrl: string;
  rating: number;
}
